const { getStore } = require("@netlify/blobs");

exports.handler = async function (event) {
  try {
    const id = event.queryStringParameters && event.queryStringParameters.id;
    const asset = event.queryStringParameters && event.queryStringParameters.asset; // 'image' or undefined

    if (!id) {
      return { statusCode: 400, body: "Missing id" };
    }

    const store = getStore("uploads");
    const raw = await store.get(`item:${id}`);

    if (!raw) {
      return { statusCode: 404, body: "Not found" };
    }

    const item = JSON.parse(raw);

    if (item.status !== "approved") {
      return { statusCode: 403, body: "Not available" };
    }

    if (asset === "image") {
      if (!item.imageBase64) {
        return { statusCode: 404, body: "No image" };
      }
      return {
        statusCode: 200,
        headers: { "Content-Type": item.imageType || "image/jpeg" },
        body: item.imageBase64,
        isBase64Encoded: true,
      };
    }

    return {
      statusCode: 200,
      headers: {
        "Content-Type": item.fileType || "application/octet-stream",
        "Content-Disposition": `attachment; filename="${item.fileName}"`,
      },
      body: item.fileBase64,
      isBase64Encoded: true,
    };
  } catch (err) {
    return { statusCode: 500, body: "Server error" };
  }
};
