const { getStore } = require("@netlify/blobs");
const crypto = require("crypto");

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { email, username, password } = JSON.parse(event.body || "{}");

    if (!email || !username || !password) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Missing fields" }),
      };
    }

    if (password.length < 6) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Password must be at least 6 characters" }),
      };
    }

    const normalizedEmail = email.trim().toLowerCase();
    const store = getStore("users");

    const existing = await store.get(`user:${normalizedEmail}`);
    if (existing) {
      return {
        statusCode: 409,
        body: JSON.stringify({ success: false, message: "This email is already registered" }),
      };
    }

    const salt = crypto.randomBytes(16).toString("hex");
    const passwordHash = hashPassword(password, salt);

    const user = {
      email: normalizedEmail,
      username: username.trim(),
      salt,
      passwordHash,
      createdAt: new Date().toISOString(),
    };

    await store.set(`user:${normalizedEmail}`, JSON.stringify(user));

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, message: "Account created! You can log in now." }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
