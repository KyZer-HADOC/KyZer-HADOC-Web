const { getStore } = require("@netlify/blobs");
const { getSessionUser } = require("./_session");

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const {
      token, name, category, fileName, fileType, fileBase64,
      description, imageBase64, imageType
    } = JSON.parse(event.body || "{}");

    const user = await getSessionUser(token);
    if (!user) {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Please log in first" }),
      };
    }

    if (!name || !category || !fileName || !fileBase64) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Missing required fields" }),
      };
    }

    const needsImage = category === "AI" || category.startsWith("Minecraft-");
    if (needsImage && !imageBase64) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Image is required for this category" }),
      };
    }

    const store = getStore("uploads");
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const item = {
      id,
      name,
      category,
      fileName,
      fileType: fileType || "application/octet-stream",
      fileBase64,
      description: description || null,
      imageBase64: imageBase64 || null,
      imageType: imageType || null,
      status: "pending",
      reason: null,
      uploaderEmail: user.email,
      uploaderUsername: user.username,
      submittedAt: new Date().toISOString(),
    };

    await store.set(`item:${id}`, JSON.stringify(item));

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, id }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
