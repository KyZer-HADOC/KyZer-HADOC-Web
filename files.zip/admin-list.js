const { getStore } = require("@netlify/blobs");

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { password } = JSON.parse(event.body || "{}");

    if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Wrong password" }),
      };
    }

    const store = getStore("uploads");
    const { blobs } = await store.list({ prefix: "item:" });

    const items = [];
    for (const b of blobs) {
      const raw = await store.get(b.key);
      if (!raw) continue;
      const item = JSON.parse(raw);
      if (item.status === "pending") {
        items.push({
          id: item.id,
          name: item.name,
          category: item.category,
          fileName: item.fileName,
          fileType: item.fileType,
          uploaderUsername: item.uploaderUsername || "Unknown",
          uploaderEmail: item.uploaderEmail || "Unknown",
          submittedAt: item.submittedAt,
        });
      }
    }

    items.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    return { statusCode: 200, body: JSON.stringify({ success: true, items }) };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
