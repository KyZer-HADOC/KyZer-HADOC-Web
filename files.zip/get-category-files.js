const { getStore } = require("@netlify/blobs");

exports.handler = async function (event) {
  try {
    const category = event.queryStringParameters && event.queryStringParameters.category;

    if (!category) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Category is required" }),
      };
    }

    const store = getStore("uploads");
    const { blobs } = await store.list({ prefix: "item:" });

    const items = [];
    for (const b of blobs) {
      const raw = await store.get(b.key);
      if (!raw) continue;
      const item = JSON.parse(raw);
      if (item.status === "approved" && item.category === category) {
        items.push({
          id: item.id,
          name: item.name,
          fileName: item.fileName,
          description: item.description || null,
          hasImage: !!item.imageBase64,
        });
      }
    }

    return { statusCode: 200, body: JSON.stringify({ success: true, items }) };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
