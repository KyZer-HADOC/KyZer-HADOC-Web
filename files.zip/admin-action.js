const { getStore } = require("@netlify/blobs");

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { password, id, action, reason } = JSON.parse(event.body || "{}");

    if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Wrong password" }),
      };
    }

    if (!id || !["approve", "reject"].includes(action)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Bad request" }),
      };
    }

    const store = getStore("uploads");
    const raw = await store.get(`item:${id}`);

    if (!raw) {
      return {
        statusCode: 404,
        body: JSON.stringify({ success: false, message: "Item not found" }),
      };
    }

    const item = JSON.parse(raw);

    if (action === "reject") {
      item.status = "rejected";
      item.reason = reason || "No reason given";
      item.rejectedAt = new Date().toISOString();
      // drop the actual file data to save space once rejected
      item.fileBase64 = null;
      await store.set(`item:${id}`, JSON.stringify(item));
      return {
        statusCode: 200,
        body: JSON.stringify({ success: true, message: "Rejected" }),
      };
    }

    // approve
    item.status = "approved";
    item.approvedAt = new Date().toISOString();
    await store.set(`item:${id}`, JSON.stringify(item));

    return { statusCode: 200, body: JSON.stringify({ success: true, message: "Approved" }) };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
