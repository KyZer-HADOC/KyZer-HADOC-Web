const { getStore } = require("@netlify/blobs");
const crypto = require("crypto");

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { email, password } = JSON.parse(event.body || "{}");

    if (!email || !password) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Missing fields" }),
      };
    }

    const normalizedEmail = email.trim().toLowerCase();
    const usersStore = getStore("users");
    const raw = await usersStore.get(`user:${normalizedEmail}`);

    if (!raw) {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Wrong email or password" }),
      };
    }

    const user = JSON.parse(raw);
    const attemptHash = hashPassword(password, user.salt);

    if (attemptHash !== user.passwordHash) {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Wrong email or password" }),
      };
    }

    const token = crypto.randomBytes(32).toString("hex");
    const sessionsStore = getStore("sessions");
    await sessionsStore.set(
      `session:${token}`,
      JSON.stringify({
        email: user.email,
        username: user.username,
        createdAt: new Date().toISOString(),
      })
    );

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, token, username: user.username }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
