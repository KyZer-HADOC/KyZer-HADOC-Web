const { getStore } = require("@netlify/blobs");
const { getSessionUser } = require("./_session");

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { token } = JSON.parse(event.body || "{}");
    const user = await getSessionUser(token);

    if (!user) {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Please log in first" }),
      };
    }

    const store = getStore("uploads");
    const { blobs } = await store.list({ prefix: "item:" });

    const items = [];
    for (const b of blobs) {
      const raw = await store.get(b.key);
      if (!raw) continue;
      const item = JSON.parse(raw);
      if (item.uploaderEmail === user.email) {
        items.push({
          id: item.id,
          name: item.name,
          category: item.category,
          fileName: item.fileName,
          status: item.status,
          reason: item.reason || null,
          submittedAt: item.submittedAt,
        });
      }
    }

    items.sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    return { statusCode: 200, body: JSON.stringify({ success: true, items }) };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Server error: " + err.message }),
    };
  }
};
