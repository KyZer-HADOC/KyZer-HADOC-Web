const { getStore } = require("@netlify/blobs");

async function getSessionUser(token) {
  if (!token) return null;
  const sessionsStore = getStore("sessions");
  const raw = await sessionsStore.get(`session:${token}`);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

module.exports = { getSessionUser };
